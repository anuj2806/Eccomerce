from django.contrib import admin
from accounts.models import *


# Register your models here.
admin.site.register(Profile)
admin.site.register(Cart)
admin.site.register(CartItems)
admin.site.register(Coupon)